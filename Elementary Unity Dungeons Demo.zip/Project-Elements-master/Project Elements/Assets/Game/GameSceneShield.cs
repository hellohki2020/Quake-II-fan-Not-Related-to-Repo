﻿using UnityEngine;
using System.Collections;

public class GameSceneShield : MonoBehaviour {

	void Start () {
	    
	}
	
	void Update () {

	}

    void onCollisionEnter2D(Collision2D other)
    {
    }
}
