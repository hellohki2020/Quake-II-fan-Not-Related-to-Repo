Testaa tata (aakkoset huomioitu) Game-kansiossa.
t. kodari v.0.0.0